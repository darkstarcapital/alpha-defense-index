import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://xkqyadgssduttoatjegy.supabase.co'

export function createSupabaseClient() {
  const key = process.env.JWT
  if (!key) throw new Error('JWT is not configured')
  return createClient(supabaseUrl, key, {
    auth: { persistSession: false, autoRefreshToken: false },
  })
}
