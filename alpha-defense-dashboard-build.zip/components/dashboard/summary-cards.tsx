import { Building2, ChartPie, ShieldCheck, TrendingUp, type LucideIcon } from 'lucide-react'
import type { Stock } from '@/lib/market-data'
import { cn } from '@/lib/utils'

type Card = { label: string; value: string; delta?: number; icon: LucideIcon; highlight?: boolean }

export function SummaryCards({ stocks, totalCompanies, changePercent }: { stocks: Stock[]; totalCompanies: number; changePercent: number }) {
  const top5 = [...stocks]
    .sort((a, b) => b.weightage - a.weightage)
    .slice(0, 5)
    .reduce((sum, s) => sum + s.weightage, 0)

  const cards: Card[] = [
    { label: 'Total Market Cap', value: '\u20B9 8,42,650 Cr', icon: TrendingUp, highlight: true },
    { label: 'No. of Companies', value: String(totalCompanies), icon: Building2 },
    { label: 'Top 5 Weightage', value: `${top5.toFixed(2)}%`, delta: 0.21, icon: ChartPie },
    { label: 'Defence Revenue (Avg.)', value: '48.32%', delta: 1.15, icon: ShieldCheck, highlight: true },
    { label: 'Total Return (2Y)', value: '+24.77%', icon: TrendingUp, highlight: true },
    { label: 'Methodology', value: 'Free-Float Market Cap', icon: ChartPie },
    { label: 'Launch Date', value: '18-Oct-2024', icon: Building2 },
    { label: 'Index P/E', value: '34.5', icon: TrendingUp },
    { label: 'Total Defence Revenue', value: '\u20B9 42,650 Cr', icon: ShieldCheck, highlight: true },
    { label: 'Avg Defence Rev. Growth', value: '+12.5%', icon: TrendingUp, highlight: true },
  ]

  return (
    <section aria-label="Index summary" className="grid grid-cols-2 gap-3 lg:grid-cols-4 2xl:grid-cols-5">
      {cards.map(({ label, value, delta, icon: Icon, highlight }) => (
        <div key={label} className="flex min-w-0 items-center gap-3 rounded-lg border border-border bg-card p-3">
          <span
            className={cn(
              'flex size-9 shrink-0 items-center justify-center rounded-full',
              highlight ? 'bg-accent text-primary' : 'bg-secondary text-foreground',
            )}
          >
            <Icon className="size-4" aria-hidden="true" />
          </span>
          <div className="min-w-0">
            <p className="text-xs text-gray-400">{label}</p>
            <p className="mt-1 flex flex-wrap items-baseline gap-x-3">
              <span className="text-lg font-semibold tabular-nums md:text-xl">{value}</span>
              {delta !== undefined && (
                <span className={cn('text-xs font-medium tabular-nums', delta >= 0 ? 'text-positive' : 'text-negative')}>
                  {delta >= 0 ? '+' : ''}
                  {delta.toFixed(2)}%
                </span>
              )}
            </p>
          </div>
        </div>
      ))}
    </section>
  )
}
