'use client'

import { useEffect, useState } from 'react'
import { ArrowDownRight, ArrowUpRight, Minus } from 'lucide-react'
import type { Stock } from '@/lib/market-data'
import { cn } from '@/lib/utils'

type Mover = { ticker: string; price: number; changePercent: number }

export function MarketPulse({ stocks }: { stocks: Stock[] }) {
  const [movers, setMovers] = useState<Mover[]>([])

  useEffect(() => {
    let cancelled = false
    const load = async () => {
      const res = await fetch('/api/market-pulse', { cache: 'no-store' })
      const json = await res.json().catch(() => null)
      if (!cancelled && json?.movers?.length) setMovers(json.movers)
    }
    load().catch(() => undefined)
    const id = window.setInterval(() => load().catch(() => undefined), 5000)
    return () => { cancelled = true; window.clearInterval(id) }
  }, [])

  const fallback = stocks.map((stock) => ({ ticker: stock.ticker, price: stock.price, changePercent: stock.changePercent ?? 0 }))
  const active = movers.length ? movers : fallback
  const gainers = [...active].sort((a, b) => b.changePercent - a.changePercent).slice(0, 3)
  const losers = [...active].sort((a, b) => a.changePercent - b.changePercent).slice(0, 3)

  return (
    <section aria-labelledby="market-pulse-title" className="rounded-xl border border-border bg-card p-4 md:p-5">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h2 id="market-pulse-title" className="text-sm font-semibold">Market Pulse</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">Today&apos;s strongest moves</p>
        </div>
        <span className="rounded-full bg-accent px-2.5 py-1 text-[10px] font-semibold tracking-wider text-primary">LIVE</span>
      </div>
      <div className="mt-4 grid gap-4 md:grid-cols-2">
        <MoverColumn title="Top Gainers" items={gainers} positive />
        <MoverColumn title="Top Losers" items={losers} />
      </div>
    </section>
  )
}

function MoverColumn({ title, items, positive = false }: { title: string; items: Mover[]; positive?: boolean }) {
  return (
    <div>
      <p className={cn('mb-2 text-xs font-medium', positive ? 'text-positive' : 'text-negative')}>{title}</p>
      <ul className="grid gap-2">
        {items.map((item) => {
          const up = item.changePercent >= 0
          const Icon = up ? ArrowUpRight : ArrowDownRight
          return (
            <li key={item.ticker} className="flex items-center justify-between rounded-md bg-secondary/60 px-3 py-2 text-xs">
              <span className="font-semibold">{item.ticker}</span>
              <span className={cn('inline-flex items-center gap-1 font-medium tabular-nums', up ? 'text-positive' : 'text-negative')}>
                <Icon className="size-3.5" aria-hidden="true" />{up ? '+' : ''}{item.changePercent.toFixed(2)}%
              </span>
            </li>
          )
        })}
        {!items.length && <li className="flex items-center gap-2 text-xs text-muted-foreground"><Minus className="size-3" />No movers yet</li>}
      </ul>
    </div>
  )
}
