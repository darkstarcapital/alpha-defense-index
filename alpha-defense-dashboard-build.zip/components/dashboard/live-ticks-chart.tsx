'use client'

import { useEffect, useRef, useState } from 'react'
import { AreaSeries, ColorType, createChart, type IChartApi, type ISeriesApi, type Time } from 'lightweight-charts'

export type LiveTickPoint = { time: number; value: number; createdAt: string }
type Tick = { created_at: string; index_value: number | string }

function getTradingDayRange() {
  const today = new Date()
  const startOfDay = Math.floor(new Date(today.getFullYear(), today.getMonth(), today.getDate(), 9, 15, 0).getTime() / 1000)
  const endOfDay = Math.floor(new Date(today.getFullYear(), today.getMonth(), today.getDate(), 15, 30, 0).getTime() / 1000)
  return { from: startOfDay as Time, to: endOfDay as Time }
}

function toSeries(ticks: Tick[]) {
  return ticks
    .map((tick) => ({
      time: Math.floor(new Date(tick.created_at).getTime() / 1000) + 19800,
      value: Number(tick.index_value),
    }))
    .filter((tick) => Number.isFinite(tick.value))
    .sort((a, b) => Number(a.time) - Number(b.time))
    .filter((tick, index, all) => index === 0 || tick.time !== all[index - 1].time)
}

export function LiveTicksChart({ fallbackValue, fallbackStart, onData }: { fallbackValue: number; fallbackStart: number; onData?: (points: LiveTickPoint[]) => void }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const chartRef = useRef<IChartApi | null>(null)
  const seriesRef = useRef<ISeriesApi<'Area'> | null>(null)
  const initializedDataRef = useRef(false)
  const latestTimeRef = useRef<number | null>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (!containerRef.current) return
    const chart = createChart(containerRef.current, {
      autoSize: true,
      layout: { background: { type: ColorType.Solid, color: 'transparent' }, textColor: '#8592a3' },
      grid: { vertLines: { color: '#18212c' }, horzLines: { color: '#18212c' } },
      rightPriceScale: { borderVisible: false, scaleMargins: { top: 0.2, bottom: 0.2 } },
      timeScale: {
        borderVisible: false,
        timeVisible: true,
        secondsVisible: true,
        fixLeftEdge: true,
        fixRightEdge: true,
        lockVisibleTimeRangeOnResize: true,
        shiftVisibleRangeOnNewBar: false,
      },
      localization: {
        timeFormatter: (time: Time) => new Date(Number(time) * 1000).toLocaleTimeString('en-IN', { hour12: false }),
      },
      crosshair: { vertLine: { color: '#19e68c', width: 1, style: 2 }, horzLine: { color: '#19e68c', width: 1, style: 2 } },
    })
    const series = chart.addSeries(AreaSeries, {
      lineColor: '#19e68c',
      topColor: 'rgba(25, 230, 140, 0.42)',
      bottomColor: 'rgba(25, 230, 140, 0.02)',
      lineWidth: 2,
      priceFormat: { type: 'price', precision: 2, minMove: 0.01 },
      autoscaleInfoProvider: (original) => {
        const info = original()
        if (!info?.priceRange) return info
        const { minValue, maxValue } = info.priceRange
        if (maxValue - minValue >= 20) return info
        const midpoint = (minValue + maxValue) / 2
        return { ...info, priceRange: { minValue: midpoint - 10, maxValue: midpoint + 10 } }
      },
    })
    chartRef.current = chart
    seriesRef.current = series

    const resizeObserver = new ResizeObserver(() => chart.resize(containerRef.current?.clientWidth ?? 0, containerRef.current?.clientHeight ?? 0))
    resizeObserver.observe(containerRef.current)
    return () => {
      resizeObserver.disconnect()
      chart.remove()
      chartRef.current = null
      seriesRef.current = null
    }
  }, [])

  useEffect(() => {
    let cancelled = false
    const load = async () => {
      try {
        const response = await fetch('/api/live-ticks', { cache: 'no-store' })
        const json = await response.json()
        if (!response.ok || json.error) throw new Error(json.error ?? 'Unable to load live ticks')
        if (cancelled || !seriesRef.current) return
        const points = toSeries(json.ticks ?? []).map((point) => ({ ...point, time: Number(point.time), createdAt: new Date(Number(point.time) * 1000).toISOString() }))
        onData?.(points)
        if (points.length > 0) {
          const latestPoint = points[points.length - 1]
          if (!initializedDataRef.current) {
            seriesRef.current.setData(points.map(({ createdAt, ...point }) => ({ ...point, time: point.time as Time })))
            chartRef.current?.timeScale().setVisibleRange(getTradingDayRange())
            initializedDataRef.current = true
          } else {
            seriesRef.current.update({ time: latestPoint.time as Time, value: latestPoint.value })
          }
          latestTimeRef.current = latestPoint.time
        }
        setError(null)
      } catch (err) {
        if (!cancelled) setError(err instanceof Error ? err.message : 'Live tick feed unavailable')
      }
    }

    load()
    const interval = window.setInterval(load, 5000)
    return () => {
      cancelled = true
      window.clearInterval(interval)
    }
  }, [])

  return (
    <div className="relative mt-6 h-[300px] w-full md:h-[400px]">
      <div ref={containerRef} className="absolute inset-0" aria-label="Live index value chart" />
      {error && (
        <p className="absolute top-2 right-2 rounded bg-background/80 px-2 py-1 text-[10px] text-muted-foreground">
          Live ticks unavailable; showing latest index value
        </p>
      )}
      <span className="sr-only">
        Live chart for index values. Current value {fallbackValue}; previous reference {fallbackStart}.
      </span>
    </div>
  )
}
